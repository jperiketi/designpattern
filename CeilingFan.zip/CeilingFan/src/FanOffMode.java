
public class FanOffMode implements FanState{

	@Override
	public void fanAction() {
		System.out.println("Fan Turned Off");
	}

}
