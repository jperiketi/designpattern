
public class FanOnMode implements FanState{

	@Override
	public void fanAction() {
		System.out.println("Fan Turned ON");
		
	}

}
