
public interface FanState {
	
	public void fanAction();
}
