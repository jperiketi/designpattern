import org.junit.jupiter.api.Test;

public class FanTest {

	@Test
	void fanTest() {
		FanState fanOnMode = new FanOnMode();
		FanState fanOffMode = new FanOffMode();
		FanContext context = new FanContext();
		context.setFanState(fanOnMode);
		context.fanAction();
		context.setFanState(fanOffMode);
		context.fanAction();
	}
}
